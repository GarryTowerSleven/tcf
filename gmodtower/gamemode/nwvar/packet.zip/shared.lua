AddCSLuaFile("shared.lua")
AddCSLuaFile("packet.lua")

REPL_EVERYONE = 0
REPL_PLAYERONLY = 1

NWTYPE_STRING = 0
NWTYPE_NUMBER = 1
NWTYPE_FLOAT = 2
NWTYPE_CHAR = 3
NWTYPE_SHORT = 4
NWTYPE_BOOL = 5
NWTYPE_BOOLEAN = NWTYPE_BOOL
NWTYPE_ANGLE = 6
NWTYPE_VECTOR = 7
NWTYPE_ENTITY = 8

DTVarToTransmitTools = {
	["String"] = NWTYPE_STRING,
	["Bool"] = NWTYPE_BOOL,
	["Float"] = NWTYPE_FLOAT,
	["Char"] = NWTYPE_CHAR,
	["Short"] = NWTYPE_SHORT,
	["Int"] = NWTYPE_NUMBER,
	["Vector"] = NWTYPE_VECTOR,
	["Angle"] = NWTYPE_ANGLE,
	["Entity"] = NWTYPE_ENTITY,
}
DTVarDefaults = {
	["String"] = "",
	["Bool"] = false,
	["Float"] = 0.0,
	["Int"] = 0,
	["Vector"] = Vector(0,0,0),
	["Angle"] = Angle(0,0,0),
	["Entity"] = Entity(0),
}

if CLIENT then
	include("packet.lua")
end

NWDEBUG = false

NW_ENTITY_DATA = NW_ENTITY_DATA or {}

if SERVER then
	require("transmittools")

	hook.Add("Tick", "NWTick", transmittools.NWTick)

	hook.Add("EntityRemoved", "NWCleanup", function(ent)

		if !IsValid(ent) or ent == GetWorldEntity() or ent:EntIndex() == 0 then return end
		
		local index = ent:EntIndex()
		NW_ENTITY_DATA[index] = nil
		
		transmittools.EntityDestroyed(index)

		if ent:IsPlayer() then
			transmittools.PlayerDestroyed(index)
		end

	end)

end

local function ApplyTableToTarget(target)

	local _t = target:GetTable()
	local etable = { _t = _t }
	local index = target:EntIndex()
	
	local mt = {
		__index = function (t,k)
			if NW_ENTITY_DATA[index] && NW_ENTITY_DATA[index].__nwtable && NW_ENTITY_DATA[index].__nwtable[k] then
				if NWDEBUG then Error("Access to property ", k, " on entity ", target) end
			end
			return t._t[k]
		end,

		__newindex = function (t,k,v)

			if NW_ENTITY_DATA[index] && NW_ENTITY_DATA[index].__nwtable && NW_ENTITY_DATA[index].__nwtable[k] then
				if NWDEBUG then Error("Access to property ", k, " on entity ", target) end
			end

			t._t[k] = v
		end
	}

	setmetatable(etable, mt)
	target:SetTable(etable)

end



local meta = FindMetaTable("Entity")
	if meta then

	function meta:GetNet(key)
		local index = self:EntIndex()
		local data = NW_ENTITY_DATA[index]
		if not data then
			local traceback = debug.traceback()
			print("\nUnable to find data for entity", self, index, key)
			print(traceback)
			return nil
		end
		
		return NW_ENTITY_DATA[index][key]
	end

	if SERVER then
		function meta:SetNet(key, value)
			local index = self:EntIndex()
			
			if not NW_ENTITY_DATA[index] then local traceback = debug.traceback() print("\nEntity is not initialized for nwvars", self, index, key) print(traceback) return end
			
			local nwtable = NW_ENTITY_DATA[index].__nwtable
			local nwvar = nwtable[key]


			if not nwvar then local traceback = debug.traceback() print("\nMissing nwtable data for key ", self, index, key) print(traceback) return end
			
			local entitydata = NW_ENTITY_DATA[index]
			if entitydata[key] == value then return end // no change

			if nwvar.type == NWTYPE_ENTITY then
				local nentindex = -1
				if IsValid(value) || value == GetWorldEntity() then
					nentindex = value:EntIndex()
				end
				transmittools.EntityVariableUpdated(index, nwvar.index-1, nentindex)
			end

			transmittools.VariableUpdated(index, nwvar.index-1)
			
			self.__nwvalues[nwvar.index] = value
			NW_ENTITY_DATA[index][key] = value
		end
	else
		function meta:SetNet(key, value)
			local index = self:EntIndex()
			NW_ENTITY_DATA[index][key] = value
		end
	end
end

function RegisterNWTable(target, ntable)

	if NWDEBUG then print("Registering table for ", target, type(ntable) != "table", #ntable == 0, type(ntable[1]) != "table") end
	
	// make sure it's a table, it has entries, and that it's a table of tables
	if type(ntable) != "table" || #ntable == 0 || type(ntable[1]) != "table" then
		return
	end
 
	local index = target:EntIndex()
	
	if NWDEBUG then print("index is", index) end
	
	if index == 0 && target != GetWorldEntity() then
		return
	end
 
	local nlookup = {}
	local first = false
 
	if not NW_ENTITY_DATA[index] then
		first = true
		NW_ENTITY_DATA[index] = {} 
	end
	
	if SERVER then
		target.__nwvalues = {}
		transmittools.NetworkedEntityCreated(index, target.__nwvalues)
	end

	for i=1, #ntable do
		local table = ntable[i]

		local name, default, type, repl = table[1], table[2], table[3], table[4]

		if NWDEBUG then
			print(name, type, repl, default)
		end

		if first then NW_ENTITY_DATA[index][name] = default end

		if CLIENT then
			// {name, type, repl, proxy}
			nlookup[i] = {name=name, type=type, repl=repl, proxy=table[5]}
		else
			// {index, type, repl}
			nlookup[name] = {index=i, type=type, repl=repl}
			transmittools.AddValue(index, i, type, repl)

			target.__nwvalues[i] = default
		end
	end

	target.__nwtable = target.__nwtable or {}
	NW_ENTITY_DATA[index].__nwtable = nlookup
	NW_ENTITY_DATA[index].__nwinit = CurTime()
 
	if SERVER then transmittools.NetworkedEntityCreatedFinish(index) end
	
	ApplyTableToTarget(target)

end

if !GetWorldEntity then
	GetWorldEntity = function() return ents.GetAll()[1] end
end

//LUAJIT
local function GetGlobalTables()
	if GlobalTables == nil then GlobalTables = {Player={}, Global={}} end
	if GlobalTables.Player == nil then GlobalTables.Player = {} end
	if GlobalTables.Global == nil then GlobalTables.Global = {} end
	return GlobalTables
end

local function SetupGlobalTable()
	RegisterNWTable( GetWorldEntity(), GetGlobalTables().Global )
end

hook.Add("OnEntityCreated", "SetupNWTablePlayer", function(ent)
	if ent == GetWorldEntity() then
		RegisterNWTable(GetWorldEntity(), GetGlobalTables().Global)
	end
 
	if !IsValid(ent) then return end

	// GM13 guard against ghosts
	local entity = ents.GetByIndex(ent:EntIndex())
	if !IsValid(entity) then return end
	
	if ent:IsPlayer() then
		if SERVER then
			transmittools.PlayerCreated(ent:EntIndex())
		end
		RegisterNWTable(ent, GetGlobalTables().Player)
	end
end)

local function MergeTablesI(a, b)
	local a = a or {}
	
	for k,v in ipairs(b) do
	-- check for any matching definitions
	local exists = false
  
	for i=1, #a do
		if a[i][1] == v[1] then 
		exists = true
		break
		end
	end
  
	if not exists then
		table.insert(a, v)
		end
	end
	
	return a
end

function RegisterNWTableGlobal(nwtable)
	//hook.Add("InitPostEntity", "SetupNWTableGlobal", SetupGlobalTable)

	// LUAJIT:
	GetGlobalTables().Global = MergeTablesI(GetGlobalTables().Global, nwtable)
end

function RegisterNWTablePlayer(nwtable)
	// LUAJIT:
	GetGlobalTables().Player = MergeTablesI(GetGlobalTables().Player, nwtable)
end

function ImplementNW()

	ENT.__OldSetupDataTables = ENT.SetupDataTables

	local function OverrideNetworkVar( self, nwType, nwIndex, nwName, nwExtend )

		local default = nil
		if type(nwExtend) != "table" then default = nwExtend end

		table.insert( self.__varTable,
			{ nwName, default or DTVarDefaults[ nwType ], DTVarToTransmitTools[ nwType ], REPL_EVERYONE }
 		)

		self["Get" .. nwName] = function( e ) return e:GetNet( nwName ) end
		self["Set" .. nwName] = function( e, value ) e:SetNet( nwName, value ) end

	end

	ENT.SetupDataTables = function( self )

		self.__varTable = {}

		self.NetworkVar = OverrideNetworkVar
		self.__OldSetupDataTables( self )

		RegisterNWTable( self, self.__varTable )

		self.__varTable = nil

	end

end

--[[if SERVER then

	util.AddNetworkString("NWHeartbeat")

	net.Receive( "NWHeartbeat", function( length, ply )
		transmittools.NWPlayerHeartbeat( ply:EntIndex()-1 )
	end )

else

	hook.Add( "Tick", "NWHeartbeat", function()

		net.Start( "NWHeartbeat" )
		net.SendToServer()

	end )

end]]