local Readers = {
	[NWTYPE_CHAR  ] = "ReadChar",
	[NWTYPE_BOOL  ] = "ReadBool",
	[NWTYPE_SHORT ] = "ReadShort",
	[NWTYPE_ENTITY] = "ReadEntity",
	[NWTYPE_STRING] = "ReadString",
	[NWTYPE_NUMBER] = "ReadLong",
	[NWTYPE_FLOAT ] = "ReadFloat",
	[NWTYPE_VECTOR] = "ReadVector"
}

-- deferred entity updates happen when the entity is not yet initialized on the client
local deferredEntityUpdates = {}
local nwEntityParity = {}

hook.Add("Think", "NWExecuteDeferredUpdates", function()
	for k, v in pairs(deferredEntityUpdates) do
		local entdata = NW_ENTITY_DATA[k]
		local entity = Entity(k)
		
		if IsValid(entity) and entdata ~= nil and entdata.__nwtable ~= nil then
			local nwtable = entdata.__nwtable
			for x = 1, #v do
				local update = v[x]
				local tbl = nwtable[update[1]]
				if not tbl then continue end
				
				if tbl.proxy then
					local b, err = pcall(tbl.proxy, entity, tbl.name, entdata[tbl.name], update[3])
					
					if !b then
						ErrorNoHalt( err )
					end
				end

				entdata[tbl.name] = update[3]
			end
			
			deferredEntityUpdates[k] = nil
		end
	end
end)

function ParsePacket(um)

 	if NWDEBUG then
 		print("parsing packet")
 	end

	local ent_index = um:ReadShort()
	local parity = um:ReadBool()
	
	if NWDEBUG then
		print("First Entity", ent_index, parity)
	end
	
	while ent_index ~= 0 do
		if ent_index == -1 then ent_index = 0 end
		
		local entdata = NW_ENTITY_DATA[ent_index]
		local entity = Entity(ent_index)
		
		if NWDEBUG then
			print("Processing Entity", ent_index, parity, entity)
		end
	
		local oldParity = nwEntityParity[ent_index]
		nwEntityParity[ent_index] = parity
		
		local deferUpdates = false
		
		if entdata and parity ~= oldParity and oldParity ~= nil then
			NW_ENTITY_DATA[ent_index] = {__nwtable = entdata.__nwtable, __nwinit = entdata.__nwinit}
			deferredEntityUpdates[ent_index] = nil
		end
		
		if not entdata or (ent_index > 0 and not IsValid(entity)) or entdata.__nwtable == nil then
			-- no data available yet
			if NWDEBUG then
				print("Deferring entity update for ", ent_index, entdata, entity)
			end
			deferUpdates = true
		end
		
		local items = um:ReadChar()

		for i=1, items do
			local index = um:ReadChar()
			local valuetype = um:ReadChar()
			if not Readers[valuetype] then
				ErrorNoHalt("NWVAR: Item was nil ", index, valuetype, "\n")
				continue
			end
			local value = um[Readers[valuetype]](um)

			if NWDEBUG then
				print(ent_index, Readers[valuetype], value)
			end
			
			if deferUpdates then
				local nwupdates = deferredEntityUpdates[ent_index] or {}
				table.insert(nwupdates, {index, valuetype, value})
				deferredEntityUpdates[ent_index] = nwupdates
			else
				local nwtable = entdata.__nwtable
				local tbl = nwtable[index]
				
				if not tbl then
					ErrorNoHalt("NWVAR: Item network table was nil ", index, "\n")
					continue
				end

				if tbl.proxy then
					local b, err = pcall(tbl.proxy, entity, tbl.name, entdata[tbl.name], value)
					
					if !b then
						ErrorNoHalt( err )
					end
				end

				entdata[tbl.name] = value
			end
 		end
 
		ent_index = um:ReadShort()
		parity = um:ReadBool()
	end
end

usermessage.Hook("N", ParsePacket)